"""VoxGuard HTTP service."""
